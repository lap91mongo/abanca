
docker-compose down
