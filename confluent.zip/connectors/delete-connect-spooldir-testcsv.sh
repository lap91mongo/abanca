echo "<<<<<<<<<<<<<<<<<<eliminando conector source spooldirCSV >>>>>>>>>>>>>>>>>>>>>>"
curl -X DELETE 'http://localhost:8083/connectors/ZPFM.FILE.CGE.TEST/' -H 'Content-Type: application/json' -w "\n"

